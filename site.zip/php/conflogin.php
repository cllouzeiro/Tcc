<?php
	echo "teste";
	php.info();
?>